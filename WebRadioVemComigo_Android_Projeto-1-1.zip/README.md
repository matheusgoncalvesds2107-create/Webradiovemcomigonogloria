# Web Rádio Vem Comigo no Glória – Android

- A rádio é acessada somente pela URL: https://webradiovemcomigonogloria.ismyradio.com/
- A chamada clássica de Hora Certa enviada pelo usuário foi integrada ao APK.
- Na virada de cada hora, o app toca automaticamente a voz correspondente à hora (`HRSxx_O`) seguida do áudio de minuto 00 (`MIN00`).
- O relógio digital mostra a hora local do aparelho.
- Os arquivos de voz enviados ficam dentro de `app/src/main/res/raw/`.

A chamada automática funciona enquanto o aplicativo estiver aberto/ativo.
