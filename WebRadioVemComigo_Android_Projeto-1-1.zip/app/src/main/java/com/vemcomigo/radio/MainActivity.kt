package com.vemcomigo.radio

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var clockView: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val clockFormat = SimpleDateFormat("HH:mm:ss", Locale("pt", "BR"))
    private var hourPlayer: MediaPlayer? = null
    private var minutePlayer: MediaPlayer? = null
    private var lastHourAnnouncement = -1
    private var audioFocusRequest: AudioFocusRequest? = null
    private lateinit var audioManager: AudioManager

    private val clockRunnable = object : Runnable {
        override fun run() {
            clockView.text = "HORA CERTA  ${clockFormat.format(Date())}"
            checkHoraCerta()
            handler.postDelayed(this, 1000L)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.rgb(7, 27, 99)
        window.navigationBarColor = Color.rgb(2, 9, 31)
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager

        val container = FrameLayout(this)
        webView = WebView(this)
        container.addView(webView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        clockView = TextView(this).apply {
            text = "HORA CERTA  --:--:--"
            setTextColor(Color.WHITE)
            setTextSize(14f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(18, 8, 18, 8)
            setBackgroundColor(Color.argb(205, 0, 0, 0))
            elevation = 12f
        }
        val clockParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            topMargin = 12
            marginEnd = 12
        }
        container.addView(clockView, clockParams)
        setContentView(container)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            loadsImagesAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = "$userAgentString WebRadioVemComigoAndroid/1.2"
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        webView.webViewClient = object : WebViewClient() {}
        webView.webChromeClient = WebChromeClient()

        // Somente a URL da rádio é usada para acessar o player/site.
        webView.loadUrl("https://webradiovemcomigonogloria.ismyradio.com/")
        handler.post(clockRunnable)
    }

    private fun checkHoraCerta() {
        val now = Calendar.getInstance()
        val hour = now.get(Calendar.HOUR_OF_DAY)
        val minute = now.get(Calendar.MINUTE)
        val second = now.get(Calendar.SECOND)
        if (minute == 0 && second <= 1 && lastHourAnnouncement != hour) {
            lastHourAnnouncement = hour
            playHoraCerta(hour)
        }
    }

    private fun playHoraCerta(hour: Int) {
        releasePlayers()
        if (requestTransientAudioFocus() == false) return

        val hourId = resources.getIdentifier("hrs%02d_o".format(hour), "raw", packageName)
        val minuteId = resources.getIdentifier("min00", "raw", packageName)
        if (hourId == 0 || minuteId == 0) {
            abandonAudioFocus()
            return
        }

        hourPlayer = MediaPlayer.create(this, hourId)
        minutePlayer = MediaPlayer.create(this, minuteId)
        hourPlayer?.setOnCompletionListener { minutePlayer?.start() }
        minutePlayer?.setOnCompletionListener {
            releasePlayers()
            abandonAudioFocus()
        }
        hourPlayer?.start()
    }

    private fun requestTransientAudioFocus(): Boolean {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(attrs)
            .setAcceptsDelayedFocusGain(false)
            .setWillPauseWhenDucked(false)
            .build()
        return audioManager.requestAudioFocus(audioFocusRequest!!) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun abandonAudioFocus() {
        audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        audioFocusRequest = null
    }

    private fun releasePlayers() {
        hourPlayer?.release()
        minutePlayer?.release()
        hourPlayer = null
        minutePlayer = null
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        handler.removeCallbacks(clockRunnable)
        releasePlayers()
        abandonAudioFocus()
        webView.destroy()
        super.onDestroy()
    }
}
