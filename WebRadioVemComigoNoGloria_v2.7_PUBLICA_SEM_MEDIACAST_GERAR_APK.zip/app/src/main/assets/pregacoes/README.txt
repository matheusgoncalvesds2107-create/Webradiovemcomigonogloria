PASTA DE PREGAÇÕES

Coloque novos arquivos .mp3 nesta pasta.
Use nomes simples, por exemplo:
01_pregacao_novo.mp3
02_pregacao_domingo.mp3

Depois de adicionar os arquivos, gere um novo APK.
