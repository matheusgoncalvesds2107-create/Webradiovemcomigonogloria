# Web Rádio Vem Comigo no Glória — v2.7 PÚBLICA

Versão pública para distribuição.

- Tela principal igual à versão privada, otimizada para Samsung A13 e aparelhos mais fracos.
- Removidos da tela principal: “TOCANDO AGORA” e o bloco “Programação / 13 programas”.
- NÃO contém integração/painel MediaCast.
- Mantém o rádio ao vivo, controles, áudio e recursos públicos do aplicativo.
- Pasta `app/src/main/assets/pregacoes/` para conteúdos que forem empacotados no APK.
- Gerar APK pelo workflow `.github/workflows/GERAR_APK_V27.yml`.
