package com.vemcomigo.radio

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var clock: TextView
    private lateinit var status: TextView
    private lateinit var nowTitle: TextView
    private lateinit var nowArtist: TextView
    private lateinit var play: TextView
    private lateinit var audioManager: AudioManager
    private val handler = Handler(Looper.getMainLooper())
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale("pt", "BR"))
    private var playing = false
    private var muted = false
    private var lastHour = -1
    private var hourPlayer: MediaPlayer? = null
    private var focusRequest: AudioFocusRequest? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        setContentView(buildUi())
        setupWeb()
        handler.post(clockTick)
    }

    private fun buildUi(): View {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        scroll.isFillViewport = true

        val root = FrameLayout(this)
        scroll.addView(root, ViewGroup.LayoutParams(-1, -2))

        // Fundo preto, como no layout de referência, com brilho azul discreto.
        val bg = View(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(bg, full())

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(12), dp(18), dp(26))
        }
        root.addView(content, FrameLayout.LayoutParams(-1, -2))

        // Cabeçalho
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val menuTop = TextView(this).apply {
            text = "☰"
            textSize = 31f
            setTextColor(Color.rgb(255, 190, 20))
            gravity = Gravity.CENTER
            setOnClickListener { showMenu() }
        }
        top.addView(menuTop, LinearLayout.LayoutParams(dp(54), dp(58)))
        top.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))
        clock = label("HORA CERTA\n--:--:--", 13f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(5), dp(12), dp(5))
            background = neonBorder(18)
        }
        top.addView(clock, LinearLayout.LayoutParams(dp(132), dp(58)))
        content.addView(top)

        val brand = label("VEM COMIGO\nNO GLÓRIA", 22f, Color.rgb(255, 190, 20), true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.03f
        }
        content.addView(brand, LinearLayout.LayoutParams(-1, dp(62)).apply { topMargin = dp(2) })

        val logoFrame = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), Color.rgb(0, 120, 255))
            }
            elevation = dp(4).toFloat()
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.radio_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(5), dp(5), dp(5), dp(5))
        }
        logoFrame.addView(logo, full())
        content.addView(logoFrame, LinearLayout.LayoutParams(-1, dp(318)).apply { topMargin = dp(4) })

        val nowCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(9), dp(10), dp(9))
            background = cardBg(14)
        }
        val singer = ImageView(this).apply {
            val id = resources.getIdentifier("divulgacao_programa_01_reflexao", "drawable", packageName)
            if (id != 0) setImageResource(id)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        nowCard.addView(singer, LinearLayout.LayoutParams(dp(88), dp(88)))
        val np = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        np.addView(label("TOCANDO AGORA", 14f, Color.rgb(255, 190, 20), true))
        nowTitle = label("Aguardando informações da rádio", 21f, Color.WHITE, true)
        np.addView(nowTitle, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(3) })
        nowArtist = label("Web Rádio Vem Comigo no Glória", 15f, Color.LTGRAY, false)
        np.addView(nowArtist, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(3) })
        nowCard.addView(np, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(nowCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        val onAir = label("●  NO AR     |     Rádio Vem Comigo no Glória", 14f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = redBorder(22)
        }
        content.addView(onAir, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) })

        status = label("Rádio pronta — toque em PLAY", 12f, Color.LTGRAY, false).apply { gravity = Gravity.CENTER }
        content.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(7), dp(8), dp(7))
            background = neonBorder(28)
        }
        val menu = control("☰", 23f, "MENU").apply { setOnClickListener { showMenu() } }
        controls.addView(menu, ctl())
        val vol1 = control("🔊", 19f, "VOLUME").apply { setOnClickListener { audioManager.adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) } }
        controls.addView(vol1, ctl())
        play = control("▶", 29f, "PLAY").apply {
            background = goldCircle()
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        }
        play.setOnClickListener { toggleRadio() }
        controls.addView(play, LinearLayout.LayoutParams(dp(86), dp(86)).apply { setMargins(dp(4), 0, dp(4), 0) })
        val vol2 = control("🔊", 19f, "VOLUME").apply { setOnClickListener { audioManager.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) } }
        controls.addView(vol2, ctl())
        val wa = control("◉", 24f, "WHATSAPP").apply {
            setTextColor(Color.rgb(85, 220, 95))
            setOnClickListener { openWhatsApp() }
        }
        controls.addView(wa, ctl())
        content.addView(controls, LinearLayout.LayoutParams(-1, dp(104)).apply { topMargin = dp(14) })

        val prog = actionButton("▣   PROGRAMAÇÃO")
        prog.setOnClickListener { showProgramacao() }
        content.addView(prog, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(12) })

        // Recursos do aplicativo
        val resources = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = cardBg(18)
            setPadding(dp(5), dp(8), dp(5), dp(8))
        }
        val r1 = resourceItem("♫", "TOCANDO\nAGORA") { scroll.smoothScrollTo(0, 0) }
        val r2 = resourceItem("▣", "PROGRAMAÇÃO") { showProgramacao() }
        val r3 = resourceItem("☏", "FALE NO\nWHATSAPP") { openWhatsApp() }
        val r4 = resourceItem("↗", "COMPARTILHAR\nRÁDIO") { shareRadio() }
        val r5 = resourceItem("◷", "HORA\nCERTA") { Toast.makeText(this, "Hora certa atualizada", Toast.LENGTH_SHORT).show() }
        val r6 = resourceItem("◉", "RÁDIO\nAO VIVO") { enterLive() }
        listOf(r1, r2, r3, r4, r5, r6).forEach { resources.addView(it, LinearLayout.LayoutParams(0, dp(88), 1f)) }
        content.addView(resources, LinearLayout.LayoutParams(-1, dp(112)).apply { topMargin = dp(14) })

        val signal = label("●  SINAL CONECTADO     |     Web Rádio Vem Comigo no Glória", 13f, Color.rgb(120, 230, 100), true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(9), dp(10), dp(9))
            background = neonBorder(18)
        }
        content.addView(signal, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        content.addView(label("Web Rádio Vem Comigo no Glória - A Rádio que Conecta Você!", 12f, Color.LTGRAY, false).apply {
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(10), dp(4), 0)
        })

        val about = label("ℹ  SOBRE A RÁDIO", 13f, Color.rgb(0, 150, 255), true).apply {
            gravity = Gravity.CENTER
            setOnClickListener { showSobre() }
        }
        content.addView(about, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(4) })

        return scroll
    }

    private fun resourceItem(icon: String, title: String, click: () -> Unit): View = TextView(this).apply {
        text = "$icon\n$title"; textSize = 10f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        setOnClickListener { click() }
    }

    private fun showMenu() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)); background = cardBg(22) }
        box.addView(label("MENU", 22f, Color.WHITE, true))
        val items = listOf(
            "🎵  PAINEL ADMIN / LOUVORES" to { showPainelLouvores() },
            "📅  PROGRAMAÇÃO COMPLETA" to { showProgramacao() },
            "📖  PALAVRA DO DIA" to { showPalavraDoDia() },
            "🎙️  AO VIVO" to { enterLive() },
            "💬  WHATSAPP" to { openWhatsApp() },
            "↗  COMPARTILHAR RÁDIO" to { shareRadio() },
            "ℹ️  SOBRE A RÁDIO" to { showSobre() }
        )
        var dialog: AlertDialog? = null
        items.forEach { (name, action) ->
            val b = button(name); b.setOnClickListener { dialog?.dismiss(); action() }; box.addView(b, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(7) })
        }
        val close = button("FECHAR"); box.addView(close, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
        dialog = AlertDialog.Builder(this).setView(box).create(); close.setOnClickListener { dialog?.dismiss() }; dialog.show()
    }

    private fun showProgramacao() {
        val items = listOf(
            "00:00   Madrugada com Deus\n06:00   Manhã com Deus\n08:00   Louvores da Manhã\n10:00   Palavra de Fé\n12:00   Louvores & Adoração\n14:00   Vem Comigo\n18:00   Programa da Noite\n20:00   Louvores da Noite\n22:00   Encerramento",
            "Programas especiais:\n01 • Reflexão\n02 • Fé Meia Hora\n03 • Vem Comigo Manhã\n04 • Meio-Dia\n05 • Almoço com Deus\n06 • Reflexão Tarde\n07 • Vem Comigo Tarde\n08 • Café e Glória\n09 • Louvor e Reflexão\n10 • Tardizinha com Deus\n11 • Fé — Edição Noite\n12 • Noite com Deus\n13 • Madrugada com Deus\nSábado • Vem Comigo Jovem"
        )
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)) }
        box.addView(label("PROGRAMAÇÃO", 22f, Color.WHITE, true))
        box.addView(label("Programação da Rádio", 14f, Color.rgb(255, 190, 20), true).apply { setPadding(0, dp(6), 0, dp(10)) })
        box.addView(ScrollView(this).apply { addView(label(items.joinToString("\n\n"), 15f, Color.WHITE, false)) }, LinearLayout.LayoutParams(-1, dp(430)))
        val close = button("FECHAR"); box.addView(close); val d = AlertDialog.Builder(this).setView(box).create(); close.setOnClickListener { d.dismiss() }; d.show()
    }

    private fun showPalavraDoDia() {
        val verses = arrayOf(
            "O Senhor é o meu pastor; nada me faltará.\n\nSalmos 23:1",
            "Tudo posso naquele que me fortalece.\n\nFilipenses 4:13",
            "Entrega o teu caminho ao Senhor; confia nele.\n\nSalmos 37:5",
            "Não temas, porque eu sou contigo.\n\nIsaías 41:10",
            "Alegrai-vos sempre no Senhor.\n\nFilipenses 4:4",
            "O Senhor te abençoe e te guarde.\n\nNúmeros 6:24",
            "Sê forte e corajoso.\n\nJosué 1:9"
        )
        val v = verses[Calendar.getInstance().get(Calendar.DAY_OF_YEAR) % verses.size]
        AlertDialog.Builder(this).setTitle("📖 PALAVRA DO DIA").setMessage(v).setPositiveButton("AMÉM", null).show()
    }

    private fun getSongs(): MutableList<String> {
        val raw = getPreferences(Context.MODE_PRIVATE).getString("songs", "") ?: ""
        return if (raw.isBlank()) mutableListOf() else raw.split("\n").filter { it.isNotBlank() }.toMutableList()
    }

    private fun saveSongs(songs: List<String>) { getPreferences(Context.MODE_PRIVATE).edit().putString("songs", songs.joinToString("\n")).apply() }

    private fun showPainelLouvores() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)) }
        box.addView(label("PAINEL ADMIN", 22f, Color.WHITE, true))
        box.addView(label("Gerenciar louvores e associar aos programas", 13f, Color.rgb(255, 190, 20), false))
        val title = EditText(this).apply { hint = "Nome do louvor"; setSingleLine(); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY) }
        val artist = EditText(this).apply { hint = "Cantor / Ministério"; setSingleLine(); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY) }
        val programs = arrayOf("01 • Reflexão", "02 • Fé Meia Hora", "03 • Vem Comigo Manhã", "04 • Meio-Dia", "05 • Almoço com Deus", "06 • Reflexão Tarde", "07 • Vem Comigo Tarde", "08 • Café e Glória", "09 • Louvor e Reflexão", "10 • Tardizinha com Deus", "11 • Fé — Edição Noite", "12 • Noite com Deus", "13 • Madrugada com Deus", "Sábado • Vem Comigo Jovem")
        val spinner = Spinner(this); spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, programs)
        box.addView(title); box.addView(artist); box.addView(spinner)
        val add = button("＋  ADICIONAR LOUVOR"); box.addView(add)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, dp(260)))
        val songs = getSongs()
        fun refresh() {
            list.removeAllViews()
            songs.forEachIndexed { i, s ->
                val p = s.split("|")
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                row.addView(label("${i + 1}. ${p.getOrElse(0) { "" }}\n${p.getOrElse(1) { "" }}\n${p.getOrElse(2) { "" }}", 12f, Color.WHITE, false), LinearLayout.LayoutParams(0, -2, 1f))
                val del = button("✕"); del.setOnClickListener { songs.removeAt(i); saveSongs(songs); refresh() }; row.addView(del, LinearLayout.LayoutParams(dp(52), dp(48))); list.addView(row)
            }
        }
        add.setOnClickListener {
            val a = title.text.toString().trim(); val b = artist.text.toString().trim()
            if (a.isBlank()) { title.error = "Digite o nome do louvor"; return@setOnClickListener }
            songs.add("$a|$b|${spinner.selectedItem}"); saveSongs(songs); title.text.clear(); artist.text.clear(); refresh()
        }
        refresh()
        val close = button("FECHAR"); box.addView(close)
        val d = AlertDialog.Builder(this).setView(box).create(); close.setOnClickListener { d.dismiss() }; d.show()
    }

    private fun showSobre() { AlertDialog.Builder(this).setTitle("Web Rádio Vem Comigo no Glória").setMessage("A Rádio que Conecta Você!\n\n📻 Rádio ao vivo\n🎵 Louvores\n🙏 Pregações\n📅 Programação\n💬 WhatsApp").setPositiveButton("FECHAR", null).show() }

    private fun openWhatsApp() {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"))) } catch (_: Exception) { Toast.makeText(this, "WhatsApp não disponível", Toast.LENGTH_SHORT).show() }
    }

    private fun shareRadio() {
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "Web Rádio Vem Comigo no Glória\nhttps://webradiovemcomigonogloria.ismyradio.com/") }
        startActivity(Intent.createChooser(i, "Compartilhar rádio"))
    }

    private fun enterLive() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1001)
        AlertDialog.Builder(this).setTitle("🎙️ AO VIVO").setMessage("O microfone do celular está disponível.\n\nPara sua voz entrar no ar durante a pregação, o MediaCast precisa estar configurado para receber a transmissão ao vivo.").setPositiveButton("ENTENDI", null).show()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWeb() {
        web = WebView(this).apply {
            alpha = 0.01f
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true; settings.mediaPlaybackRequiresUserGesture = false
            settings.loadsImagesAutomatically = false; settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            webChromeClient = WebChromeClient(); webViewClient = object : WebViewClient() { override fun onPageFinished(view: WebView?, url: String?) { status.text = "Rádio pronta — toque em PLAY" } }
        }
        CookieManager.getInstance().setAcceptCookie(true); CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        addContentView(web, FrameLayout.LayoutParams(2, 2).apply { leftMargin = 1; topMargin = 1 })
        web.loadUrl("https://webradiovemcomigonogloria.ismyradio.com/")
    }

    private fun toggleRadio() {
        if (playing) {
            web.evaluateJavascript("(function(){var a=document.querySelector('audio');if(a)a.pause();})()", null)
            playing = false; play.text = "▶\nPLAY"; status.text = "Rádio pausada"
        } else {
            web.evaluateJavascript("(function(){var a=document.querySelector('audio');if(a){a.muted=false;a.play().catch(function(){});return;}var b=document.querySelector('[aria-label*=Play i],button');if(b)b.click();})()", null)
            playing = true; play.text = "Ⅱ\nPARAR"; status.text = "Rádio em reprodução"
        }
    }

    private val clockTick = object : Runnable {
        override fun run() {
            clock.text = "HORA CERTA\n${fmt.format(Date())}"
            val c = Calendar.getInstance(); val h = c.get(Calendar.HOUR_OF_DAY)
            if (c.get(Calendar.MINUTE) == 0 && c.get(Calendar.SECOND) <= 1 && lastHour != h) { lastHour = h; playHour(h) }
            handler.postDelayed(this, 1000L)
        }
    }

    private fun playHour(hour: Int) {
        hourPlayer?.release(); hourPlayer = null
        val id = resources.getIdentifier("hrs%02d_o".format(hour), "raw", packageName); if (id == 0) return
        requestFocus(); hourPlayer = MediaPlayer.create(this, id); hourPlayer?.setOnCompletionListener { it.release(); hourPlayer = null; abandonFocus() }; hourPlayer?.start()
    }

    private fun requestFocus() {
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
        if (Build.VERSION.SDK_INT >= 26) { focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).setAudioAttributes(attrs).setAcceptsDelayedFocusGain(false).build(); audioManager.requestAudioFocus(focusRequest!!) }
        else audioManager.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
    }

    private fun abandonFocus() { if (Build.VERSION.SDK_INT >= 26) focusRequest?.let { audioManager.abandonAudioFocusRequest(it) } else audioManager.abandonAudioFocus(null); focusRequest = null }

    private fun label(s: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply { text = s; textSize = size; setTextColor(color); typeface = Typeface.create(Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL) }
    private fun control(icon: String, size: Float, name: String) = label("$icon\n$name", size, Color.WHITE, true).apply { gravity = Gravity.CENTER; setPadding(dp(2), dp(2), dp(2), dp(2)) }
    private fun actionButton(s: String) = label(s, 16f, Color.rgb(0, 150, 255), true).apply { gravity = Gravity.CENTER; background = neonBorder(18) }
    private fun button(s: String) = label(s, 15f, Color.WHITE, true).apply { gravity = Gravity.CENTER; background = cardBg(12); setPadding(dp(8), dp(8), dp(8), dp(8)) }
    private fun ctl() = LinearLayout.LayoutParams(0, dp(78), 1f)
    private fun full() = FrameLayout.LayoutParams(-1, -1)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun cardBg(r: Int) = GradientDrawable().apply { setColor(Color.argb(205, 5, 5, 8)); cornerRadius = dp(r).toFloat(); setStroke(dp(1), Color.rgb(30, 120, 255)) }
    private fun neonBorder(r: Int) = GradientDrawable().apply { setColor(Color.argb(175, 0, 0, 0)); cornerRadius = dp(r).toFloat(); setStroke(dp(1), Color.rgb(0, 135, 255)) }
    private fun redBorder(r: Int) = GradientDrawable().apply { setColor(Color.argb(210, 170, 0, 0)); cornerRadius = dp(r).toFloat(); setStroke(dp(1), Color.rgb(255, 20, 20)) }
    private fun goldCircle() = GradientDrawable().apply { setColor(Color.rgb(255, 190, 20)); shape = GradientDrawable.OVAL; setStroke(dp(2), Color.rgb(255, 215, 70)) }
}
