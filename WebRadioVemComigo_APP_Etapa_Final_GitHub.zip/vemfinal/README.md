# Web Rádio Vem Comigo no Glória — versão 2.0

Aplicativo Android com interface própria inspirada no modelo enviado pelo usuário.

- Usa somente o endereço público da rádio: https://webradiovemcomigonogloria.ismyradio.com/
- Não coloca URL direta de streaming no código.
- Tela própria, sem exibir anúncios ou o site inteiro.
- Botão PLAY tenta iniciar o player da própria página da rádio.
- Hora Certa em tempo real (24h).
- Área para louvor atual e programação, lidos da página quando a rádio os disponibilizar.
- Controle de volume/mudo e atualização.
