package com.vemcomigo.radio

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var clock: TextView
    private lateinit var status: TextView
    private lateinit var play: TextView
    private lateinit var nowPlaying: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale("pt", "BR"))
    private var playing = false
    private var muted = false
    private var lastHour = -1
    private var hourPlayer: MediaPlayer? = null
    private var focusRequest: AudioFocusRequest? = null
    private lateinit var audioManager: AudioManager

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        setContentView(buildUi())
        setupWeb()
        handler.post(clockTick)
    }

    private fun buildUi(): View {
        val root = FrameLayout(this)
        root.background = resources.getDrawable(R.drawable.bg_radio, theme)
        root.addView(View(this).apply { setBackgroundColor(Color.argb(105,0,0,0)) }, full())

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(12), dp(18), dp(112))
        }
        root.addView(content, full())

        val top = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        top.addView(text("✚  VEM COMIGO NO GLÓRIA",18f,Color.WHITE,true),
            LinearLayout.LayoutParams(0,dp(42),1f))
        clock = text("HORA CERTA  --:--:--",13f,Color.WHITE,true).apply {
            gravity=Gravity.CENTER; setPadding(dp(10),dp(7),dp(10),dp(7))
            background=rounded(Color.argb(220,0,0,0),dp(20))
        }
        top.addView(clock,LinearLayout.LayoutParams(-2,dp(38)))
        content.addView(top)

        val ticker=text("WEB RÁDIO VEM COMIGO NO GLÓRIA",18f,Color.WHITE,true).apply{
            gravity=Gravity.CENTER; setPadding(dp(12),dp(8),dp(12),dp(8))
            background=rounded(Color.argb(180,0,0,0),dp(18))
        }
        content.addView(ticker,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(10)})

        val logo=ImageView(this).apply{setImageResource(R.drawable.radio_logo);scaleType=ImageView.ScaleType.CENTER_INSIDE}
        content.addView(logo,LinearLayout.LayoutParams(dp(205),dp(175)).apply{topMargin=dp(2)})

        status=text("Conectando à rádio...",14f,Color.WHITE,false).apply{gravity=Gravity.CENTER}
        content.addView(status,LinearLayout.LayoutParams(-1,-2))

        nowPlaying=text("🎵 TOCANDO AGORA\nAguardando informações da rádio",14f,Color.WHITE,true).apply{
            gravity=Gravity.CENTER; setPadding(dp(12),dp(9),dp(12),dp(9))
            background=rounded(Color.argb(185,0,0,0),dp(16))
        }
        content.addView(nowPlaying,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(8)})

        val live=text("●  NO AR  •  Rádio Vem Comigo no Glória",14f,Color.WHITE,true).apply{
            gravity=Gravity.CENTER;setPadding(dp(12),dp(8),dp(12),dp(8))
            background=rounded(Color.argb(215,125,0,0),dp(18))
        }
        content.addView(live,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(8)})

        val spacer=View(this)
        content.addView(spacer,LinearLayout.LayoutParams(1,0,1f))

        val quick=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
        val prog=smallButton("📅\nPROGRAMAÇÃO"); prog.setOnClickListener{showProgramacao()}
        val word=smallButton("📖\nPALAVRA DO DIA"); word.setOnClickListener{showPalavraDoDia()}
        val liveBtn=smallButton("🎙️\nAO VIVO"); liveBtn.setOnClickListener{enterLive()}
        quick.addView(prog,LinearLayout.LayoutParams(0,dp(66),1f).apply{setMargins(dp(3),0,dp(3),0)})
        quick.addView(word,LinearLayout.LayoutParams(0,dp(66),1f).apply{setMargins(dp(3),0,dp(3),0)})
        quick.addView(liveBtn,LinearLayout.LayoutParams(0,dp(66),1f).apply{setMargins(dp(3),0,dp(3),0)})
        content.addView(quick)

        val controls=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER
            setPadding(dp(8),dp(7),dp(8),dp(7))
            background=rounded(Color.argb(235,12,12,15),dp(30));elevation=dp(7).toFloat()
        }
        root.addView(controls,FrameLayout.LayoutParams(-1,dp(82)).apply{
            gravity=Gravity.BOTTOM;leftMargin=dp(22);rightMargin=dp(22);bottomMargin=dp(14)
        })

        val menu=control("☰",24f);menu.setOnClickListener{showMenu()};controls.addView(menu,lp())
        val vol=control("🔊",20f);vol.setOnClickListener{audioManager.adjustVolume(AudioManager.ADJUST_RAISE,AudioManager.FLAG_SHOW_UI)};controls.addView(vol,lp())
        play=control("▶",31f).apply{background=rounded(Color.WHITE,dp(40));setTextColor(Color.BLACK)}
        play.setOnClickListener{toggleRadio()};controls.addView(play,LinearLayout.LayoutParams(dp(70),dp(68)).apply{setMargins(dp(5),0,dp(5),0)})
        val mute=control("🔇",20f);mute.setOnClickListener{
            muted=!muted
            web.evaluateJavascript("(function(){var a=document.querySelector('audio');if(a)a.muted=${muted};})()",null)
            mute.text=if(muted)"🔇" else "🔊"
        };controls.addView(mute,lp())
        val share=control("↗",27f);share.setOnClickListener{shareRadio()};controls.addView(share,lp())
        return root
    }

    private fun showMenu(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(18));background=rounded(Color.argb(248,8,8,10),dp(22))}
        box.addView(text("MENU",20f,Color.WHITE,true))
        val about=button("ℹ️  SOBRE A RÁDIO");about.setOnClickListener{showSobre();};box.addView(about)
        val whats=button("💬  WHATSAPP");whats.setOnClickListener{openWhatsApp()};box.addView(whats)
        val admin=button("🎵  PAINEL DE LOUVORES");admin.setOnClickListener{showPainelLouvores()};box.addView(admin)
        val close=button("FECHAR");box.addView(close)
        val overlay=FrameLayout(this);overlay.addView(box,FrameLayout.LayoutParams(-1,-2).apply{leftMargin=dp(18);rightMargin=dp(18);topMargin=dp(95)})
        close.setOnClickListener{(overlay.parent as? ViewGroup)?.removeView(overlay)}
        addContentView(overlay,FrameLayout.LayoutParams(-1,-1))
    }


    private fun getSongs(): MutableList<String> {
        val raw=getPreferences(Context.MODE_PRIVATE).getString("songs","") ?: ""
        return if(raw.isBlank()) mutableListOf() else raw.split("\n").filter{it.isNotBlank()}.toMutableList()
    }

    private fun saveSongs(songs: List<String>) {
        getPreferences(Context.MODE_PRIVATE).edit().putString("songs",songs.joinToString("\n")).apply()
    }

    private fun showPainelLouvores(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(18))}
        box.addView(text("🎵 PAINEL DE LOUVORES",21f,Color.WHITE,true))
        box.addView(text("Cadastre o louvor, cantor e programa. A lista fica salva neste aparelho.",13f,Color.LTGRAY,false).apply{setPadding(0,dp(6),0,dp(12))})
        val title=EditText(this).apply{hint="Nome do louvor";setTextColor(Color.WHITE);setHintTextColor(Color.LTGRAY)}
        val artist=EditText(this).apply{hint="Cantor / Ministério";setTextColor(Color.WHITE);setHintTextColor(Color.LTGRAY)}
        val program=Spinner(this)
        val programs=arrayOf("01 • Reflexão","02 • Fé Meia Hora","03 • Vem Comigo Manhã","04 • Meio-Dia","05 • Almoço com Deus","06 • Reflexão Tarde","07 • Vem Comigo Tarde","08 • Café e Glória","09 • Louvor e Reflexão","10 • Tardizinha com Deus","11 • Fé — Edição Noite","12 • Noite com Deus","13 • Madrugada com Deus","Sábado • Vem Comigo Jovem")
        program.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,programs)
        box.addView(title);box.addView(artist);box.addView(program)
        val add=button("➕ ADICIONAR LOUVOR")
        box.addView(add)
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        box.addView(ScrollView(this).apply{addView(list)},LinearLayout.LayoutParams(-1,dp(280)))
        val songs=getSongs()
        fun refresh(){
            list.removeAllViews()
            songs.forEachIndexed { i,s ->
                val p=s.split("|")
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                row.addView(text("${i+1}. ${p.getOrElse(0){""}}\\n${p.getOrElse(1){""}}\\n${p.getOrElse(2){""}}",13f,Color.WHITE,false),LinearLayout.LayoutParams(0,-2,1f))
                val del=button("✕");del.setOnClickListener{songs.removeAt(i);saveSongs(songs);refresh()};row.addView(del,LinearLayout.LayoutParams(dp(55),-2))
                list.addView(row)
            }
        }
        add.setOnClickListener{
            val a=title.text.toString().trim();val b=artist.text.toString().trim()
            if(a.isBlank()){title.error="Digite o nome do louvor";return@setOnClickListener}
            songs.add("$a|$b|${program.selectedItem}")
            saveSongs(songs);title.text.clear();artist.text.clear();refresh()
        }
        refresh()
        val close=button("FECHAR");box.addView(close)
        val d=android.app.AlertDialog.Builder(this).setView(box).create();close.setOnClickListener{d.dismiss()};d.show()
    }

    private fun showProgramacao(){
        val items=listOf(
            "01 • Reflexão","02 • Fé Meia Hora","03 • Vem Comigo Manhã","04 • Meio-Dia",
            "05 • Almoço com Deus","06 • Reflexão Tarde","07 • Vem Comigo Tarde",
            "08 • Café e Glória","09 • Louvor e Reflexão","10 • Tardizinha com Deus",
            "11 • Fé — Edição Noite","12 • Noite com Deus","13 • Madrugada com Deus",
            "Sábado • Vem Comigo Jovem"
        )
        val songs=getSongs()
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(18));background=rounded(Color.argb(248,8,8,10),dp(22))}
        box.addView(text("📅 PROGRAMAÇÃO",20f,Color.WHITE,true))
        val list=TextView(this).apply{setText(items.joinToString("\n\n"));textSize=15f;setTextColor(Color.WHITE);setPadding(0,dp(14),0,0)}
        box.addView(ScrollView(this).apply{addView(list)},LinearLayout.LayoutParams(-1,dp(300)))
        box.addView(text("🎵 Louvores cadastrados: ${songs.size}",14f,Color.WHITE,false).apply{setPadding(0,dp(10),0,dp(6))})
        if(songs.isNotEmpty()) box.addView(text(songs.joinToString("\n"){ "• ${it.substringBefore("|")} — ${it.substringAfter("|").substringBefore("|")}"},13f,Color.WHITE,false))
        val close=button("FECHAR");box.addView(close)
        val d=android.app.AlertDialog.Builder(this).setView(box).create();close.setOnClickListener{d.dismiss()};d.show()
    }

    private fun showPalavraDoDia(){
        val verses=arrayOf(
            "“O Senhor é o meu pastor; nada me faltará.”\nSalmos 23:1",
            "“Tudo posso naquele que me fortalece.”\nFilipenses 4:13",
            "“Entrega o teu caminho ao Senhor; confia nele.”\nSalmos 37:5",
            "“Não temas, porque eu sou contigo.”\nIsaías 41:10",
            "“Alegrai-vos sempre no Senhor.”\nFilipenses 4:4",
            "“O Senhor te abençoe e te guarde.”\nNúmeros 6:24",
            "“Sê forte e corajoso.”\nJosué 1:9"
        )
        val v=verses[Calendar.getInstance().get(Calendar.DAY_OF_YEAR)%verses.size]
        android.app.AlertDialog.Builder(this).setTitle("📖 PALAVRA DO DIA").setMessage(v).setPositiveButton("AMÉM"){d,_ -> d.dismiss()}.show()
    }

    private fun showSobre(){
        android.app.AlertDialog.Builder(this).setTitle("Web Rádio Vem Comigo no Glória")
            .setMessage("Uma rádio feita para levar louvores, mensagens de fé, esperança e Palavra de Deus até você.\n\n📻 Rádio ao vivo\n🎵 Louvores\n🙏 Pregações\n📅 Programação\n💬 WhatsApp")
            .setPositiveButton("FECHAR",null).show()
    }

    private fun openWhatsApp(){
        try{
            startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/")))
        }catch(_:Exception){
            status.text="WhatsApp não disponível"
        }
    }

    private fun shareRadio(){
        val i=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,"Web Rádio Vem Comigo no Glória\nhttps://webradiovemcomigonogloria.ismyradio.com/")}
        startActivity(Intent.createChooser(i,"Compartilhar rádio"))
    }

    private fun enterLive(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),1001)
        }
        android.app.AlertDialog.Builder(this).setTitle("🎙️ AO VIVO")
            .setMessage("O microfone do celular está pronto para ser usado.\n\nA entrada da sua voz no ar depende da configuração de transmissão ao vivo do MediaCast.")
            .setPositiveButton("ENTENDI",null).show()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWeb(){
        web=WebView(this);web.alpha=0.01f
        web.settings.javaScriptEnabled=true;web.settings.domStorageEnabled=true
        web.settings.mediaPlaybackRequiresUserGesture=false;web.settings.loadsImagesAutomatically=false
        web.settings.mixedContentMode=WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(web,true)
        web.webChromeClient=WebChromeClient()
        web.webViewClient=object:WebViewClient(){override fun onPageFinished(view:WebView?,url:String?){status.text="Rádio pronta — toque em PLAY"}}
        addContentView(web,FrameLayout.LayoutParams(2,2).apply{leftMargin=1;topMargin=1})
        web.loadUrl("https://webradiovemcomigonogloria.ismyradio.com/")
    }

    private fun toggleRadio(){
        if(playing){
            web.evaluateJavascript("(function(){var a=document.querySelector('audio');if(a)a.pause();})()",null)
            playing=false;play.text="▶";status.text="Rádio pausada"
        }else{
            web.evaluateJavascript("(function(){var a=document.querySelector('audio');if(a){a.muted=false;a.play().catch(function(){});return;}var b=document.querySelector('[aria-label*=Play i],button');if(b)b.click();})()",null)
            playing=true;play.text="Ⅱ";status.text="Rádio em reprodução"
        }
    }

    private val clockTick=object:Runnable{
        override fun run(){
            clock.text="HORA CERTA  ${fmt.format(Date())}"
            val c=Calendar.getInstance();val h=c.get(Calendar.HOUR_OF_DAY)
            if(c.get(Calendar.MINUTE)==0&&c.get(Calendar.SECOND)<=1&&lastHour!=h){lastHour=h;playHour(h)}
            handler.postDelayed(this,1000L)
        }
    }

    private fun playHour(hour:Int){
        hourPlayer?.release();hourPlayer=null
        val id=resources.getIdentifier("hrs%02d_o".format(hour),"raw",packageName)
        if(id==0)return
        requestFocus();hourPlayer=MediaPlayer.create(this,id)
        hourPlayer?.setOnCompletionListener{it.release();hourPlayer=null;abandonFocus()};hourPlayer?.start()
    }

    private fun requestFocus(){
        val attrs=AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
        if(Build.VERSION.SDK_INT>=26){
            focusRequest=AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).setAudioAttributes(attrs).setAcceptsDelayedFocusGain(false).build()
            audioManager.requestAudioFocus(focusRequest!!)
        }else audioManager.requestAudioFocus(null,AudioManager.STREAM_MUSIC,AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
    }
    private fun abandonFocus(){
        if(Build.VERSION.SDK_INT>=26) focusRequest?.let{audioManager.abandonAudioFocusRequest(it)}
        else audioManager.abandonAudioFocus(null)
        focusRequest=null
    }

    private fun text(s:String,size:Float,color:Int,bold:Boolean)=TextView(this).apply{text=s;textSize=size;setTextColor(color);typeface=Typeface.create(Typeface.DEFAULT,if(bold)Typeface.BOLD else Typeface.NORMAL)}
    private fun control(s:String,size:Float)=text(s,size,Color.WHITE,true).apply{gravity=Gravity.CENTER}
    private fun button(s:String)=TextView(this).apply{text=s;textSize=15f;setTextColor(Color.WHITE);setPadding(dp(12),dp(12),dp(12),dp(12));background=rounded(Color.argb(100,255,255,255),dp(14))}
    private fun smallButton(s:String)=TextView(this).apply{text=s;textSize=11f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setTypeface(null,Typeface.BOLD);background=rounded(Color.argb(180,0,0,0),dp(14))}
    private fun lp()=LinearLayout.LayoutParams(0,dp(62),1f)
    private fun full()=FrameLayout.LayoutParams(-1,-1)
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun rounded(c:Int,r:Int)=android.graphics.drawable.GradientDrawable().apply{setColor(c);cornerRadius=r.toFloat()}

    override fun onDestroy(){handler.removeCallbacks(clockTick);hourPlayer?.release();abandonFocus();if(::web.isInitialized)web.destroy();super.onDestroy()}
}
