package com.vemcomigo.radio

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var clock: TextView
    private lateinit var status: TextView
    private lateinit var nowTitle: TextView
    private lateinit var nowArtist: TextView
    private lateinit var nowImage: ImageView
    private lateinit var play: TextView
    private lateinit var audioManager: AudioManager
    private val handler = Handler(Looper.getMainLooper())
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale("pt", "BR"))
    private var playing = false
    private var hourPlayer: MediaPlayer? = null
    private var panelPlayer: MediaPlayer? = null
    private var lastHour = -1

    private data class Program(val n:Int, val start:String, val end:String, val name:String, val image:String, val desc:String)

    private val programs = listOf(
        Program(1,"00:00","04:30","Madrugada com Deus","divulgacao_programa_13_madrugada_com_deus","Palavra, oração e louvores durante a madrugada"),
        Program(2,"04:30","05:00","Fé Meia Hora","divulgacao_programa_02_fe_meia_hora","Uma mensagem curta para começar o dia com fé"),
        Program(3,"05:00","08:00","Vem Comigo Manhã","divulgacao_programa_03_vem_comigo_manha","Louvores, reflexão e companhia para sua manhã"),
        Program(4,"08:00","10:00","Meia-Dia","divulgacao_programa_04_meia_dia","Informação, música e mensagens edificantes"),
        Program(5,"10:00","12:00","Almoço com Deus","divulgacao_programa_05_almoco_com_deus","Louvores e palavra para acompanhar seu almoço"),
        Program(6,"12:00","14:00","Reflexão Tarde","divulgacao_programa_06_reflexao_tarde","Reflexões para fortalecer sua fé"),
        Program(7,"14:00","16:00","Vem Comigo Tarde","divulgacao_programa_07_vem_comigo_tarde","Sua tarde com música e informação"),
        Program(8,"16:00","18:00","Café e Glória","divulgacao_programa_08_cafe_e_gloria","Um café com louvores e boas mensagens"),
        Program(9,"18:00","20:00","Louvor e Reflexão","divulgacao_programa_09_louvor_e_reflexao","Louvores e uma palavra para o seu coração"),
        Program(10,"20:00","21:00","Tardizinha com Deus","divulgacao_programa_10_tardizinha_com_deus","Momento especial de fé e adoração"),
        Program(11,"21:00","22:00","Fé Noite","divulgacao_programa_11_fe_noite","Mensagem e louvor para fechar o dia"),
        Program(12,"22:00","00:00","Noite com Deus","divulgacao_programa_12_noite_com_deus","Noite de oração, palavra e louvores"),
        Program(13,"00:00","04:30","Madrugada com Deus","divulgacao_programa_13_madrugada_com_deus","Programação da madrugada" )
    )

    private val sermons = listOf(
        "01_deus_ainda_faz" to "Deus ainda faz milagres",
        "02_nao_desista" to "Não desista",
        "03_fogo_no_altar" to "Fogo no altar",
        "04_deus_abre_portas" to "Deus abre portas",
        "05_fe_na_tempestade" to "Fé na tempestade",
        "06_o_poder_da_oracao" to "O poder da oração",
        "07_deus_conhece_voce" to "Deus conhece você",
        "08_tempo_de_recomeco" to "Tempo de recomeço",
        "09_protecao_da_familia" to "Proteção da família",
        "10_quando_deus_diz_espere" to "Quando Deus diz espere",
        "11_levanta_e_caminha" to "Levanta e caminha",
        "12_santidade_no_dia_a_dia" to "Santidade no dia a dia",
        "13_gratidao" to "Gratidão em todo tempo",
        "14_o_melhor_ainda_vem" to "O melhor ainda vem",
        "15_aviva_nos" to "Aviva-nos, Senhor"
    )

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        setContentView(buildUi())
        setupWeb()
        handler.post(clockTick)
    }

    private fun buildUi(): View {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.BLACK); isFillViewport = true }
        val content = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER_HORIZONTAL; setPadding(dp(10),dp(7),dp(10),dp(16)) }
        scroll.addView(content, ViewGroup.LayoutParams(-1,-2))

        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(label("☰",29f,Color.rgb(255,190,20),true).apply{gravity=Gravity.CENTER;setOnClickListener{showMenu()}},LinearLayout.LayoutParams(dp(52),dp(50)))
        top.addView(Space(this),LinearLayout.LayoutParams(0,1,1f))
        clock=label("HORA CERTA\n--:--:--",12f,Color.WHITE,true).apply{gravity=Gravity.CENTER;background=neonBorder(18);setPadding(dp(8),dp(3),dp(8),dp(3))}
        top.addView(clock,LinearLayout.LayoutParams(dp(120),dp(50)))
        content.addView(top)

        val logoFrame=FrameLayout(this).apply{background=cardBg(22)}
        val logo=ImageView(this).apply{setImageResource(R.drawable.microfone_radio);scaleType=ImageView.ScaleType.CENTER_INSIDE;setPadding(dp(5),dp(5),dp(5),dp(5))}
        logoFrame.addView(logo,full())
        content.addView(logoFrame,LinearLayout.LayoutParams(-1,dp(250)).apply{topMargin=dp(3)})

        val now=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;background=cardBg(15);setPadding(dp(7),dp(7),dp(7),dp(7))}
        nowImage=ImageView(this).apply{setImageResource(R.drawable.divulgacao_programa_09_louvor_e_reflexao);scaleType=ImageView.ScaleType.CENTER_CROP}
        now.addView(nowImage,LinearLayout.LayoutParams(dp(72),dp(72)))
        val nt=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),0,0,0)}
        nt.addView(label("TOCANDO AGORA",13f,Color.rgb(255,190,20),true))
        nowTitle=label("Web Rádio Vem Comigo no Glória",18f,Color.WHITE,true);nt.addView(nowTitle,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(2)})
        nowArtist=label("Aguardando informações da rádio",13f,Color.LTGRAY,false);nt.addView(nowArtist,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(3)})
        now.addView(nt,LinearLayout.LayoutParams(0,-2,1f));content.addView(now,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(9)})

        status=label("Rádio em reprodução",13f,Color.LTGRAY,false).apply{gravity=Gravity.CENTER};content.addView(status,LinearLayout.LayoutParams(-1,dp(30)))

        val controls=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;background=neonBorder(28);setPadding(dp(5),dp(5),dp(5),dp(5))}
        controls.addView(control("☰","MENU"){showMenu()},ctl())
        controls.addView(control("🔊","VOLUME −"){audioManager.adjustVolume(AudioManager.ADJUST_LOWER,AudioManager.FLAG_SHOW_UI)},ctl())
        play=control("▶","TOCAR"){toggleRadio()}.apply{background=goldCircle();setTextColor(Color.BLACK)}
        controls.addView(play,LinearLayout.LayoutParams(dp(68),dp(68)).apply{setMargins(dp(2),0,dp(2),0)})
        controls.addView(control("🔊","VOLUME +"){audioManager.adjustVolume(AudioManager.ADJUST_RAISE,AudioManager.FLAG_SHOW_UI)},ctl())
        controls.addView(control("↗","COMPARTILHAR"){shareRadio()},ctl())
        content.addView(controls,LinearLayout.LayoutParams(-1,dp(78)).apply{topMargin=dp(8)})

        val tabs=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(0,dp(5),0,0)}
        tabs.addView(actionButton("▣  PROGRAMAÇÃO"){showProgramacao()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(4),0)})
        tabs.addView(actionButton("🎛  ÁUDIO"){showPainelAudio()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),0,0,0)})
        content.addView(tabs,LinearLayout.LayoutParams(-1,dp(53)))

        content.addView(label("📺  PROGRAMAÇÃO   •   13 PROGRAMAS",18f,Color.WHITE,true).apply{setPadding(dp(4),dp(12),dp(4),dp(8))})
        val guide=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        programs.forEach{guide.addView(programCard(it),LinearLayout.LayoutParams(-1,dp(78)).apply{bottomMargin=dp(5)})}
        content.addView(guide)

        val signal=label("●  SINAL CONECTADO     |     WebRadioVemComigoNoGloria",12f,Color.rgb(100,235,90),true).apply{gravity=Gravity.CENTER;background=neonBorder(18);setPadding(dp(5),dp(7),dp(5),dp(7))}
        content.addView(signal,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(8)})
        content.addView(label("Web Rádio Vem Comigo no Glória • A Rádio que Conecta Você!",11f,Color.LTGRAY,false).apply{gravity=Gravity.CENTER;setPadding(0,dp(9),0,0)})
        return scroll
    }

    private fun programCard(p:Program):View{
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;background=cardBg(12);setPadding(dp(5),dp(4),dp(5),dp(4));setOnClickListener{showProgramDetails(p)}}
        val img=ImageView(this).apply{val id=resources.getIdentifier(p.image,"drawable",packageName);if(id!=0)setImageResource(id);scaleType=ImageView.ScaleType.CENTER_CROP}
        row.addView(img,LinearLayout.LayoutParams(dp(68),dp(68)))
        val txt=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(9),0,0,0)}
        txt.addView(label("${p.n}. ${p.name}",14f,Color.WHITE,true))
        txt.addView(label("${p.start} às ${p.end}",12f,Color.rgb(255,195,20),true),LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(2)})
        txt.addView(label(p.desc,10f,Color.LTGRAY,false),LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(2)})
        row.addView(txt,LinearLayout.LayoutParams(0,-2,1f));return row
    }

    private fun showProgramDetails(p:Program){
        val v=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(15),dp(15),dp(15),dp(15));background=cardBg(18)}
        val img=ImageView(this).apply{val id=resources.getIdentifier(p.image,"drawable",packageName);if(id!=0)setImageResource(id);scaleType=ImageView.ScaleType.CENTER_CROP}
        v.addView(img,LinearLayout.LayoutParams(-1,dp(180)))
        v.addView(label("${p.n}. ${p.name}",20f,Color.WHITE,true).apply{setPadding(0,dp(10),0,dp(2))})
        v.addView(label("${p.start} às ${p.end}\n\n${p.desc}",13f,Color.LTGRAY,false))
        val d=AlertDialog.Builder(this).setView(v).setPositiveButton("FECHAR",null).create();d.show()
    }

    private fun showMenu(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(16),dp(16),dp(16));background=cardBg(20)}
        box.addView(label("MENU",21f,Color.WHITE,true))
        val items=listOf("🎛  PAINEL DE ÁUDIO" to {showPainelAudio()},"📺  PROGRAMAÇÃO" to {showProgramacao()},"📖  PALAVRA DO DIA" to {showPalavraDoDia()},"↗  COMPARTILHAR" to {shareRadio()},"ℹ  SOBRE A RÁDIO" to {showSobre()})
        var d:AlertDialog?=null
        items.forEach{(name,action)->val b=button(name);b.setOnClickListener{d?.dismiss();action()};box.addView(b,LinearLayout.LayoutParams(-1,dp(46)).apply{topMargin=dp(7)})}
        val close=button("FECHAR");box.addView(close,LinearLayout.LayoutParams(-1,dp(46)).apply{topMargin=dp(8)});d=AlertDialog.Builder(this).setView(box).create();close.setOnClickListener{d?.dismiss()};d.show()
    }

    private fun showProgramacao(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(10),dp(10),dp(10));background=ColorDrawableCompat.black()}
        box.addView(label("PROGRAMAÇÃO • 13 PROGRAMAS",20f,Color.WHITE,true).apply{setPadding(dp(5),dp(4),0,dp(8))})
        val scroll=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};programs.forEach{list.addView(programCard(it),LinearLayout.LayoutParams(-1,dp(78)).apply{bottomMargin=dp(5)})};scroll.addView(list);box.addView(scroll,LinearLayout.LayoutParams(-1,dp(520)))
        AlertDialog.Builder(this).setView(box).setPositiveButton("FECHAR",null).show()
    }

    private fun showPainelAudio(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(10),dp(10),dp(10));background=ColorDrawableCompat.black()}
        box.addView(label("🎛  PAINEL DE ÁUDIO",20f,Color.WHITE,true))
        val tabs=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val scroll=ScrollView(this);scroll.addView(content);box.addView(tabs,LinearLayout.LayoutParams(-1,dp(48)));box.addView(scroll,LinearLayout.LayoutParams(-1,dp(460)))
        fun fill(items:List<Triple<String,String,String>>){content.removeAllViews();items.forEach{audioRow(it.first,it.second,it.third,content)}}
        val vin=listOf("vinheta_01" to "Vinheta 01","asset_2__vinheta_02" to "Vinheta 02","vinheta_03" to "Vinheta 03","vinheta_04" to "Vinheta 04","vinheta_05" to "Vinheta 05","vinheta_06" to "Vinheta 06").map{Triple(it.second,"Vinheta da rádio",it.first)}
        val callNames=listOf("asset_01_inicio_p05_almoco_com_deus" to "Início • Almoço com Deus","asset_02_final_p05_almoco_com_deus" to "Final • Almoço com Deus","asset_03_inicio_p06_reflexao_tarde" to "Início • Reflexão Tarde","asset_04_final_p06_reflexao_tarde" to "Final • Reflexão Tarde","asset_05_inicio_p07_vem_comigo_tarde" to "Início • Vem Comigo Tarde","asset_06_final_p07_vem_comigo_tarde" to "Final • Vem Comigo Tarde","asset_07_inicio_p08_vem_comigo_cafe_e_gloria" to "Início • Café e Glória","asset_08_final_p08_vem_comigo_cafe_e_gloria" to "Final • Café e Glória","asset_09_inicio_p09_louvor_e_reflexao" to "Início • Louvor e Reflexão","asset_10_final_p09_louvor_e_reflexao" to "Final • Louvor e Reflexão","asset_11_inicio_p10_tardizinha_com_deus" to "Início • Tardizinha com Deus","asset_12_final_p10_tardizinha_com_deus" to "Final • Tardizinha com Deus","asset_13_inicio_p11_fe_edicao_noite" to "Início • Fé Noite","asset_14_final_p11_fe_edicao_noite" to "Final • Fé Noite","asset_15_inicio_p12_noite_com_deus" to "Início • Noite com Deus","asset_16_final_p12_noite_com_deus" to "Final • Noite com Deus","asset_17_inicio_p13_madrugada_com_deus" to "Início • Madrugada com Deus","asset_18_final_p13_madrugada_com_deus" to "Final • Madrugada com Deus").map{Triple(it.second,"Chamada da programação",it.first)}
        val pre=sermons.map{Triple("🎤 ${it.second}","Pregação • toque para ouvir","pregacao_${it.first}")}
        val hrs=(0..23).map{Triple("Hora certa ${String.format("%02d:00",it)}","Vinheta da hora","hrs${String.format("%02d",it)}_o")}
        val buttons=listOf("🎵 LOUVORES" to {showPainelLouvores(content)},"🎙 VINHETAS" to {fill(vin)},"📢 CHAMADAS" to {fill(callNames)},"🙏 PREGAÇÕES" to {fill(pre)},"🕐 HORAS" to {fill(hrs)})
        buttons.forEach{(n,a)->val b=button(n);b.textSize=9f;b.setOnClickListener{a()};tabs.addView(b,LinearLayout.LayoutParams(0,dp(44),1f).apply{setMargins(dp(2),0,dp(2),0)})}
        fill(pre)
        val d=AlertDialog.Builder(this).setView(box).setPositiveButton("FECHAR",null).create();d.show()
    }

    private fun showPainelLouvores(target:LinearLayout){
        target.removeAllViews()
        val songs=getSongs()
        target.addView(label("Louvores cadastrados neste aparelho",14f,Color.rgb(255,195,20),true).apply{setPadding(dp(5),dp(5),dp(5),dp(10))})
        if(songs.isEmpty()) target.addView(label("Nenhum louvor cadastrado ainda.\nUse o cadastro abaixo para guardar nome e cantor.",12f,Color.LTGRAY,false).apply{setPadding(dp(5),0,dp(5),dp(10))})
        songs.forEachIndexed{i,s->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;background=cardBg(10);setPadding(dp(8),dp(5),dp(5),dp(5))}
            row.addView(label(s,13f,Color.WHITE,true),LinearLayout.LayoutParams(0,dp(46),1f));val del=button("✕");del.setOnClickListener{val x=getSongs();x.removeAt(i);saveSongs(x);showPainelLouvores(target)};row.addView(del,LinearLayout.LayoutParams(dp(50),dp(42)));target.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(4)})
        }
        val add=button("＋  CADASTRAR LOUVOR");add.setOnClickListener{val input=EditText(this);input.hint="Título — cantor";AlertDialog.Builder(this).setTitle("Novo louvor").setView(input).setNegativeButton("CANCELAR",null).setPositiveButton("SALVAR"){_,_->val s=input.text.toString().trim();if(s.isNotEmpty()){val x=getSongs();x.add(s);saveSongs(x);showPainelLouvores(target)}}.show()};target.addView(add,LinearLayout.LayoutParams(-1,dp(48)).apply{topMargin=dp(8)})
    }

    private fun audioRow(title:String,sub:String,resName:String,list:LinearLayout){val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;background=cardBg(10);setPadding(dp(8),dp(5),dp(5),dp(5))};val t=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};t.addView(label(title,13f,Color.WHITE,true));t.addView(label(sub,10f,Color.LTGRAY,false),LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(2)});row.addView(t,LinearLayout.LayoutParams(0,-2,1f));val b=button("▶");b.setOnClickListener{playPanelAudio(resName)};row.addView(b,LinearLayout.LayoutParams(dp(50),dp(42)));list.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(4)})}
    private fun playPanelAudio(resName:String){try{panelPlayer?.release();val id=resources.getIdentifier(resName,"raw",packageName);if(id==0){Toast.makeText(this,"Áudio não encontrado",Toast.LENGTH_SHORT).show();return};panelPlayer=MediaPlayer.create(this,id);panelPlayer?.setOnCompletionListener{it.release();panelPlayer=null};panelPlayer?.start()}catch(_:Exception){Toast.makeText(this,"Não foi possível tocar",Toast.LENGTH_SHORT).show()}}

    private fun getSongs():MutableList<String>{val s=getPreferences(Context.MODE_PRIVATE).getString("songs","")?:"";return if(s.isBlank())mutableListOf() else s.split("\n").toMutableList()}
    private fun saveSongs(x:List<String>){getPreferences(Context.MODE_PRIVATE).edit().putString("songs",x.joinToString("\n")).apply()}
    private fun showPalavraDoDia(){val v=arrayOf("O Senhor é o meu pastor; nada me faltará.\n\nSalmos 23:1","Tudo posso naquele que me fortalece.\n\nFilipenses 4:13","Não temas, porque eu sou contigo.\n\nIsaías 41:10")[Calendar.getInstance().get(Calendar.DAY_OF_YEAR)%3];AlertDialog.Builder(this).setTitle("📖 PALAVRA DO DIA").setMessage(v).setPositiveButton("AMÉM",null).show()}
    private fun showSobre(){AlertDialog.Builder(this).setTitle("Web Rádio Vem Comigo no Glória").setMessage("A Rádio que Conecta Você!\n\n📻 Rádio ao vivo\n🎵 Louvores\n🙏 Pregações\n📺 13 programas\n⏰ Hora certa").setPositiveButton("FECHAR",null).show()}
    private fun shareRadio(){val i=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,"Web Rádio Vem Comigo no Glória\nhttps://webradiovemcomigonogloria.ismyradio.com/")};startActivity(Intent.createChooser(i,"Compartilhar rádio"))}

    @SuppressLint("SetJavaScriptEnabled") private fun setupWeb(){web=WebView(this).apply{alpha=0.01f;settings.javaScriptEnabled=true;settings.domStorageEnabled=true;settings.mediaPlaybackRequiresUserGesture=false;settings.loadsImagesAutomatically=false;settings.mixedContentMode=WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE;webChromeClient=WebChromeClient();webViewClient=object:WebViewClient(){override fun onPageFinished(view:WebView?,url:String?){status.text="Rádio pronta — toque em TOCAR"}}};CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);addContentView(web,FrameLayout.LayoutParams(2,2).apply{leftMargin=1;topMargin=1});web.loadUrl("https://webradiovemcomigonogloria.ismyradio.com/")}
    private fun toggleRadio(){if(playing){web.evaluateJavascript("(function(){var a=document.querySelector('audio');if(a)a.pause();})()",null);playing=false;play.text="▶\nTOCAR";status.text="Rádio pausada"}else{web.evaluateJavascript("(function(){var a=document.querySelector('audio');if(a){a.muted=false;a.play().catch(function(){});return;}var b=document.querySelector('[aria-label*=Play i],button');if(b)b.click();})()",null);playing=true;play.text="Ⅱ\nPAUSAR";status.text="Rádio em reprodução"}}
    private val clockTick=object:Runnable{override fun run(){clock.text="HORA CERTA\n${fmt.format(Date())}";val c=Calendar.getInstance();val h=c.get(Calendar.HOUR_OF_DAY);if(c.get(Calendar.MINUTE)==0&&c.get(Calendar.SECOND)<=1&&lastHour!=h){lastHour=h;playHour(h)};handler.postDelayed(this,1000)}}
    private fun playHour(h:Int){hourPlayer?.release();val id=resources.getIdentifier("hrs%02d_o".format(h),"raw",packageName);if(id==0)return;hourPlayer=MediaPlayer.create(this,id);hourPlayer?.setOnCompletionListener{it.release();hourPlayer=null};hourPlayer?.start()}
    override fun onDestroy(){handler.removeCallbacks(clockTick);hourPlayer?.release();panelPlayer?.release();web.destroy();super.onDestroy()}

    private fun label(s:String,size:Float,color:Int,bold:Boolean)=TextView(this).apply{text=s;textSize=size;setTextColor(color);typeface=Typeface.create(Typeface.DEFAULT,if(bold)Typeface.BOLD else Typeface.NORMAL)}
    private fun button(s:String)=label(s,12f,Color.WHITE,true).apply{gravity=Gravity.CENTER;background=cardBg(12);setPadding(dp(6),dp(6),dp(6),dp(6))}
    private fun actionButton(s:String,click:()->Unit)=label(s,13f,Color.rgb(0,160,255),true).apply{gravity=Gravity.CENTER;background=neonBorder(16);setOnClickListener{click()}}
    private fun control(icon:String,name:String,click:()->Unit)=label("$icon\n$name",10f,Color.WHITE,true).apply{gravity=Gravity.CENTER;setOnClickListener{click()}}
    private fun ctl()=LinearLayout.LayoutParams(0,dp(68),1f)
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun full()=FrameLayout.LayoutParams(-1,-1)
    private fun cardBg(r:Int)=GradientDrawable().apply{setColor(Color.argb(205,5,5,8));cornerRadius=dp(r).toFloat();setStroke(dp(1),Color.rgb(20,120,255))}
    private fun neonBorder(r:Int)=GradientDrawable().apply{setColor(Color.argb(175,0,0,0));cornerRadius=dp(r).toFloat();setStroke(dp(1),Color.rgb(0,135,255))}
    private fun goldCircle()=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(Color.rgb(255,190,20));setStroke(dp(1),Color.rgb(255,220,90))}
}

private object ColorDrawableCompat { fun black(): GradientDrawable = GradientDrawable().apply { setColor(Color.BLACK) } }
