# Web Rádio Vem Comigo no Glória — Android

Projeto Android nativo que abre a página oficial da rádio em um WebView otimizado para celular.

## Endereço usado
https://webradiovemcomigonogloria.ismyradio.com/

A página da rádio fornece o player ao vivo da Caster.fm.

## Como gerar o APK
1. Abra esta pasta no Android Studio.
2. Aguarde o Gradle sincronizar.
3. Use **Build > Build APK(s)**.
4. O APK estará em `app/build/outputs/apk/debug/app-debug.apk`.

O projeto já inclui:
- nome da rádio;
- ícone baseado no logo fornecido;
- orientação retrato;
- JavaScript e armazenamento web habilitados;
- reprodução de mídia;
- navegação interna;
- permissão de internet.