# Web Rádio Vem Comigo no Glória

Aplicativo Android da Web Rádio Vem Comigo no Glória.

O aplicativo usa somente a página oficial da rádio:
https://webradiovemcomigonogloria.ismyradio.com/

Recursos:
- Player e conteúdo carregados pela URL da rádio
- Nome do louvor/programação quando disponibilizados pela página
- Hora Certa em formato 24 horas, atualizada a cada segundo
- Java/Kotlin configurados para JVM 17
