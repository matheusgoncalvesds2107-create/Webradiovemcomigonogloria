# Web Rádio Vem Comigo no Glória — APK Lite

Projeto Android nativo, simples e leve, preparado para abrir no Android Studio e gerar APK.

- Fundo azul forte em gradiente
- Player nativo MediaPlayer
- Play/Pause
- Botão SITE
- Android 6.0+ (minSdk 23)
- Sem WebView
- Sem React Native
- Sem bibliotecas de áudio externas
- Não usa imagem de outro projeto

## Stream público usado pelo player
http://sapircast.caster.fm:19513/QKnuH

As credenciais `source` não são incluídas no APK.

## Gerar APK
No Android Studio: **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
