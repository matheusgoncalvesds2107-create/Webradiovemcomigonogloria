package com.vemcomigo.radio;

import android.app.Activity;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;

public class MainActivity extends Activity {
    private static final String STREAM_URL = "http://sapircast.caster.fm:19513/QKnuH";
    private static final String SITE_URL = "https://webradiovemcomigonogloria.ismyradio.com/";
    private MediaPlayer player;
    private Button playButton;
    private TextView status;
    private final Handler handler = new Handler();
    private TextView clock;
    private final SimpleDateFormat clockFormat = new SimpleDateFormat("HH:mm:ss", Locale("pt", "BR"));
    private final Runnable clockRunnable = new Runnable() { public void run() { if (clock != null) clock.setText("HORA CERTA  " + clockFormat.format(new Date())); handler.postDelayed(this, 1000L); } };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(0, 35, 105));
        buildUi();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL); root.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.setBackgroundResource(R.drawable.blue_background);

        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(0,0,0,dp(10));
        TextView menu = text("☰", 28, Color.WHITE, false); top.addView(menu, new LinearLayout.LayoutParams(dp(55), dp(50)));
        TextView titleTop = text("WEB RÁDIO", 16, Color.WHITE, true); top.addView(titleTop, new LinearLayout.LayoutParams(0,dp(50),1));
        clock = text("HORA CERTA  --:--:--", 12, Color.rgb(255,220,0), true); top.addView(clock, new LinearLayout.LayoutParams(dp(125),dp(50)));
        root.addView(top, new LinearLayout.LayoutParams(-1, dp(60)));

        TextView main = text("WEB RÁDIO", 30, Color.WHITE, true); root.addView(main, new LinearLayout.LayoutParams(-1, dp(48)));
        TextView name = text("Vem Comigo no Glória", 19, Color.rgb(255,220,0), true); root.addView(name, new LinearLayout.LayoutParams(-1, dp(36)));
        TextView mic = text("🎙", 92, Color.WHITE, false); root.addView(mic, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView info = text("MÚSICA • FÉ • INFORMAÇÃO • AO VIVO", 11, Color.WHITE, true); root.addView(info, new LinearLayout.LayoutParams(-1,dp(32)));
        status = text("RÁDIO PRONTA PARA TOCAR", 14, Color.WHITE, true); root.addView(status, new LinearLayout.LayoutParams(-1,dp(35)));

        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(12),dp(7),dp(12),dp(7)); bar.setBackgroundResource(R.drawable.player_background);
        TextView label = text("Aperte PLAY", 13, Color.WHITE, true); bar.addView(label, new LinearLayout.LayoutParams(0,dp(58),1));
        playButton = new Button(this); playButton.setText("▶"); playButton.setTextSize(22); playButton.setTextColor(Color.BLACK); playButton.setAllCaps(false); playButton.setBackgroundResource(R.drawable.play_background);
        playButton.setOnClickListener(v -> toggle()); bar.addView(playButton, new LinearLayout.LayoutParams(dp(70),dp(58)));
        TextView site = text("SITE", 12, Color.WHITE, true); site.setOnClickListener(v -> openSite()); bar.addView(site, new LinearLayout.LayoutParams(dp(65),dp(58)));
        root.addView(bar, new LinearLayout.LayoutParams(-1,dp(74)));

        menu.setOnClickListener(v -> Toast.makeText(this, "Web Rádio Vem Comigo no Glória", Toast.LENGTH_SHORT).show());
        setContentView(root);
        handler.post(clockRunnable);
    }

    private void toggle() {
        if (player != null && player.isPlaying()) { stopRadio(); return; }
        startRadio();
    }

    private void startRadio() {
        status.setText("CONECTANDO À RÁDIO..."); playButton.setText("❚❚");
        try {
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build());
            player.setDataSource(STREAM_URL);
            player.setOnPreparedListener(mp -> { mp.start(); status.setText("🔴 RÁDIO EM REPRODUÇÃO"); });
            player.setOnErrorListener((mp, what, extra) -> { status.setText("NÃO FOI POSSÍVEL CONECTAR"); playButton.setText("▶"); releasePlayer(); Toast.makeText(this,"Verifique a internet e tente novamente.",Toast.LENGTH_SHORT).show(); return true; });
            player.prepareAsync();
        } catch (Exception e) { status.setText("ERRO AO ABRIR A RÁDIO"); playButton.setText("▶"); releasePlayer(); }
    }

    private void stopRadio() { if (player != null) { try { if (player.isPlaying()) player.stop(); } catch(Exception ignored){} } playButton.setText("▶"); status.setText("RÁDIO PARADA"); releasePlayer(); }
    private void releasePlayer() { if (player != null) { try { player.reset(); player.release(); } catch(Exception ignored){} player=null; } }
    private void openSite() { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(SITE_URL))); }
    @Override protected void onStop() { super.onStop(); if (player != null) releasePlayer(); }
    @Override protected void onDestroy() { handler.removeCallbacks(clockRunnable); releasePlayer(); super.onDestroy(); }
}
