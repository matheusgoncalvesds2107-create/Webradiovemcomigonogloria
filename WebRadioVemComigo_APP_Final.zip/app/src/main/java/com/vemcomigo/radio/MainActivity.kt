package com.vemcomigo.radio

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var clock: TextView
    private lateinit var status: TextView
    private lateinit var play: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale("pt", "BR"))
    private var playing = false
    private var muted = false
    private var lastHour = -1
    private var hourPlayer: MediaPlayer? = null
    private var focusRequest: AudioFocusRequest? = null
    private lateinit var audioManager: AudioManager

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        setContentView(buildUi())
        setupWeb()
        handler.post(clockTick)
    }

    private fun buildUi(): View {
        val root = FrameLayout(this)
        root.background = resources.getDrawable(R.drawable.bg_radio, theme)
        root.addView(View(this).apply { setBackgroundColor(Color.argb(105, 0, 0, 0)) }, full())

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(14), dp(18), dp(118))
        }
        root.addView(content, full())

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = text("✚  VEM COMIGO NO GLÓRIA", 18f, Color.WHITE, true)
        top.addView(brand, LinearLayout.LayoutParams(0, dp(42), 1f))
        clock = text("HORA CERTA  --:--:--", 13f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(7), dp(10), dp(7))
            background = rounded(Color.argb(220,0,0,0), dp(20))
        }
        top.addView(clock, LinearLayout.LayoutParams(-2, dp(38)))
        content.addView(top)

        val ticker = text("WEB RÁDIO VEM COMIGO NO GLÓRIA", 19f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(9), dp(12), dp(9))
            background = rounded(Color.argb(180,0,0,0), dp(18))
        }
        content.addView(ticker, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        val logo = ImageView(this).apply { setImageResource(R.drawable.radio_logo); scaleType = ImageView.ScaleType.CENTER_INSIDE }
        content.addView(logo, LinearLayout.LayoutParams(dp(210), dp(190)).apply { topMargin = dp(6) })

        status = text("Conectando à rádio...", 14f, Color.WHITE, false).apply { gravity = Gravity.CENTER }
        content.addView(status, LinearLayout.LayoutParams(-1, -2))

        val info = text("MÚSICA • FÉ • INFORMAÇÃO • AO VIVO", 13f, Color.LTGRAY, true).apply { gravity = Gravity.CENTER }
        content.addView(info, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })

        val spacer = View(this)
        content.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))

        val live = text("●  NO AR  •  Rádio Vem Comigo no Glória", 14f, Color.WHITE, true).apply {
            setPadding(dp(14), dp(9), dp(14), dp(9))
            background = rounded(Color.argb(215,125,0,0), dp(18))
        }
        content.addView(live, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(7), dp(8), dp(7))
            background = rounded(Color.argb(235,12,12,15), dp(30))
            elevation = dp(7).toFloat()
        }
        root.addView(controls, FrameLayout.LayoutParams(-1, dp(82)).apply {
            gravity = Gravity.BOTTOM; leftMargin = dp(22); rightMargin = dp(22); bottomMargin = dp(18)
        })

        val menu = control("☰", 24f)
        menu.setOnClickListener { showMenu() }
        controls.addView(menu, lp())
        val vol = control("🔊", 20f)
        vol.setOnClickListener { audioManager.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }
        controls.addView(vol, lp())
        play = control("▶", 31f).apply { background = rounded(Color.WHITE, dp(40)); setTextColor(Color.BLACK) }
        play.setOnClickListener { toggleRadio() }
        controls.addView(play, LinearLayout.LayoutParams(dp(70), dp(68)).apply { setMargins(dp(5),0,dp(5),0) })
        val mute = control("🔇", 20f)
        mute.setOnClickListener {
            muted = !muted
            web.evaluateJavascript("(function(){var a=document.querySelector('audio');if(a)a.muted=${muted};})()", null)
            mute.text = if (muted) "🔇" else "🔊"
        }
        controls.addView(mute, lp())
        val refresh = control("→", 30f)
        refresh.setOnClickListener { status.text = "Atualizando rádio..."; web.reload() }
        controls.addView(refresh, lp())
        return root
    }

    private fun showMenu() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18),dp(18),dp(18),dp(18)); background = rounded(Color.argb(245,8,8,10),dp(22)) }
        box.addView(text("MENU",18f,Color.WHITE,true))
        box.addView(text("Web Rádio Vem Comigo no Glória\n\n▶ Toque no botão central para ouvir\n🔊 Volume pelos botões do telefone\n🕐 A Hora Certa é anunciada automaticamente a cada hora cheia.",15f,Color.WHITE,false), LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(14)})
        // Close handled by a temporary dialog-like overlay instead.
        val overlay = FrameLayout(this)
        overlay.addView(box, FrameLayout.LayoutParams(-1, dp(300)).apply{leftMargin=dp(18);rightMargin=dp(18);topMargin=dp(100)})
        val c = text("FECHAR",14f,Color.WHITE,true).apply{gravity=Gravity.CENTER;setPadding(dp(10),dp(10),dp(10),dp(10));background=rounded(Color.argb(120,255,255,255),dp(16))}
        box.addView(c, LinearLayout.LayoutParams(-1,dp(48)).apply{topMargin=dp(18)})
        c.setOnClickListener{(overlay.parent as? ViewGroup)?.removeView(overlay)}
        addContentView(overlay, FrameLayout.LayoutParams(-1,-1))
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWeb() {
        web = WebView(this)
        web.alpha = 0.01f
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.loadsImagesAutomatically = false
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) { status.text = "Rádio pronta — toque em PLAY" }
        }
        addContentView(web, FrameLayout.LayoutParams(2,2).apply{leftMargin=1;topMargin=1})
        web.loadUrl("https://webradiovemcomigonogloria.ismyradio.com/")
    }

    private fun toggleRadio() {
        if (playing) {
            web.evaluateJavascript("(function(){var a=document.querySelector('audio');if(a)a.pause();})()", null)
            playing=false; play.text="▶"; status.text="Rádio pausada"
        } else {
            web.evaluateJavascript("(function(){var a=document.querySelector('audio');if(a){a.muted=false;a.play().catch(function(){});return;}var b=document.querySelector('[aria-label*=Play i],button');if(b)b.click();})()", null)
            playing=true; play.text="Ⅱ"; status.text="Rádio em reprodução"
        }
    }

    private val clockTick = object : Runnable {
        override fun run() {
            clock.text = "HORA CERTA  ${fmt.format(Date())}"
            val c=Calendar.getInstance(); val h=c.get(Calendar.HOUR_OF_DAY)
            if(c.get(Calendar.MINUTE)==0 && c.get(Calendar.SECOND)<=1 && lastHour!=h){lastHour=h;playHour(h)}
            handler.postDelayed(this,1000L)
        }
    }

    private fun playHour(hour:Int) {
        hourPlayer?.release(); hourPlayer=null
        val id=resources.getIdentifier("hrs%02d_o".format(hour),"raw",packageName)
        if(id==0)return
        requestFocus()
        hourPlayer=MediaPlayer.create(this,id)
        hourPlayer?.setOnCompletionListener{it.release();hourPlayer=null;abandonFocus()}
        hourPlayer?.start()
    }

    private fun requestFocus() {
        val attrs=AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
        if(Build.VERSION.SDK_INT>=26){
            focusRequest=AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).setAudioAttributes(attrs).setAcceptsDelayedFocusGain(false).build()
            audioManager.requestAudioFocus(focusRequest!!)
        } else audioManager.requestAudioFocus(null,AudioManager.STREAM_MUSIC,AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
    }
    private fun abandonFocus(){ if(Build.VERSION.SDK_INT>=26) focusRequest?.let{audioManager.abandonAudioFocusRequest(it)} else audioManager.abandonAudioFocus(null,AudioManager.STREAM_MUSIC); focusRequest=null }

    private fun text(s:String,size:Float,color:Int,bold:Boolean)=TextView(this).apply{ text=s;textSize=size;setTextColor(color);typeface=Typeface.create(Typeface.DEFAULT,if(bold)Typeface.BOLD else Typeface.NORMAL) }
    private fun control(s:String,size:Float)=text(s,size,Color.WHITE,true).apply{gravity=Gravity.CENTER}
    private fun lp()=LinearLayout.LayoutParams(0,dp(62),1f)
    private fun full()=FrameLayout.LayoutParams(-1,-1)
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun rounded(c:Int,r:Int)=android.graphics.drawable.GradientDrawable().apply{setColor(c);cornerRadius=r.toFloat()}

    override fun onDestroy(){handler.removeCallbacks(clockTick);hourPlayer?.release();abandonFocus();if(::web.isInitialized)web.destroy();super.onDestroy()}
}
