# Web Rádio Vem Comigo no Glória — Studio REAL

Projeto Android/React Native novo, independente dos projetos anteriores.

- React Native 0.76.9
- Android SDK 35
- Java 17
- Gradle 8.10.2
- Encoder nativo Android com captura de microfone, LAME MP3 e envio Icecast
- Configuração MediaCast/Icecast no aparelho

Servidor configurado como referência do MediaCast:
- Host: sapircast.caster.fm
- Porta: 19513
- Usuário: source
- Mountpoint: /QKnuH
- Bitrate: 128 kbps MP3

A senha não é armazenada no código-fonte: deve ser informada pelo operador no aparelho.

O workflow de geração do APK é entregue separadamente e deve ser colocado em `.github/workflows/` no repositório.
