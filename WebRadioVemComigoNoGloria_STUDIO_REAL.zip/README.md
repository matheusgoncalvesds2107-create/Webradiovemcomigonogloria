# Web Rádio Vem Comigo no Glória — Studio

Projeto novo e separado, baseado na tela `StudioEncoderApp.js` fornecida para este aplicativo.

## Encoder real
- Captura real do microfone com `AudioRecord`.
- MP3 CBR 128 kbps via TAndroidLame.
- Conexão real ao Icecast/MediaCast por socket HTTP PUT.
- Host padrão: `sapircast.caster.fm` / porta `19513`.
- Usuário padrão: `source` / mountpoint `/QKnuH`.
- Senha é digitada no aparelho e não é gravada no código-fonte.
- Reconexão automática após perda de conexão.
- Serviço Android em primeiro plano para manter a transmissão ativa.
- Seleção de áudio local pelo seletor Android e entrada do áudio selecionado no fluxo.
- Microfone pode ser ligado/desligado durante a transmissão.

## APK
O ambiente desta sessão não possui Android SDK/Gradle nem acesso de rede para baixar o SDK, portanto o APK binário não foi falsamente fabricado. O workflow separado `GERAR_APK_STUDIO_REAL.yml` compila o APK debug em GitHub Actions.

## Observação
A senha do Icecast não é incluída no projeto nem no workflow. Ela deve ser informada no aplicativo.


Build baseline: React Native 0.76.9, Android Gradle Plugin 8.6.0, Gradle 8.10.2, Java 17. Native Android code is Java-only; Kotlin plugin is intentionally not used.
