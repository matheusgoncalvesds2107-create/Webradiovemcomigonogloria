package com.vemcomigo.studio;

import android.app.Application;
import com.facebook.react.PackageList;
import com.facebook.react.ReactApplication;
import com.facebook.react.ReactNativeHost;
import com.facebook.react.ReactPackage;
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint;
import com.facebook.react.defaults.DefaultReactNativeHost;
import com.facebook.react.soloader.OpenSourceMergedSoMapping;
import com.facebook.soloader.SoLoader;
import java.util.List;

public class MainApplication extends Application implements ReactApplication {
  private final ReactNativeHost mReactNativeHost = new DefaultReactNativeHost(this) {
    @Override public boolean getUseDeveloperSupport(){ return BuildConfig.DEBUG; }
    @Override protected List<ReactPackage> getPackages(){
      List<ReactPackage> packages = new PackageList(this).getPackages();
      packages.add(new RadioEncoderPackage());
      return packages;
    }
    @Override protected String getJSMainModuleName(){ return "index"; }
    @Override protected boolean isNewArchEnabled(){ return BuildConfig.IS_NEW_ARCHITECTURE_ENABLED; }
    @Override protected Boolean isHermesEnabled(){ return BuildConfig.IS_HERMES_ENABLED; }
  };
  @Override public ReactNativeHost getReactNativeHost(){ return mReactNativeHost; }
  @Override public void onCreate(){ super.onCreate(); SoLoader.init(this, OpenSourceMergedSoMapping.INSTANCE); if(BuildConfig.IS_NEW_ARCHITECTURE_ENABLED) DefaultNewArchitectureEntryPoint.load(); }
}
