package com.vemcomigo.studio;
import com.facebook.react.ReactActivity;
public class MainActivity extends ReactActivity { @Override protected String getMainComponentName(){ return "WebRadioVemComigoNoGloriaStudio"; } }
