package com.vemcomigo.studio;
import com.facebook.react.ReactPackage; import com.facebook.react.bridge.NativeModule; import com.facebook.react.bridge.ReactApplicationContext; import com.facebook.react.uimanager.ViewManager; import java.util.*;
public class RadioEncoderPackage implements ReactPackage {
 public List<NativeModule> createNativeModules(ReactApplicationContext c){return Collections.<NativeModule>singletonList(new RadioEncoderModule(c));}
 public List<ViewManager> createViewManagers(ReactApplicationContext c){return Collections.emptyList();}
}
