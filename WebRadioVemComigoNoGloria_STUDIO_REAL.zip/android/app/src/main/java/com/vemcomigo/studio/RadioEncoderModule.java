package com.vemcomigo.studio;

import android.app.Activity; import android.content.*; import android.net.Uri; import android.provider.OpenableColumns;
import androidx.annotation.Nullable;
import com.facebook.react.bridge.*; import java.util.*;

public class RadioEncoderModule extends ReactContextBaseJavaModule implements ActivityEventListener {
  static ReactApplicationContext ctx; static final int PICK=9021; private Promise pickerPromise;
  public RadioEncoderModule(ReactApplicationContext c){super(c);ctx=c;c.addActivityEventListener(this);}
  @Override public String getName(){return "RadioEncoder";}
  @ReactMethod public void start(ReadableMap cfg, Promise p){ try{ Intent i=new Intent(ctx,RadioEncoderService.class); i.setAction("START"); i.putExtra("host",cfg.getString("host")); i.putExtra("port",cfg.getInt("port")); i.putExtra("username",cfg.getString("username")); i.putExtra("mountpoint",cfg.getString("mountpoint")); i.putExtra("password",cfg.getString("password")); i.putExtra("bitrate",cfg.getInt("bitrate")); i.putExtra("sampleRate",cfg.getInt("sampleRate")); if(android.os.Build.VERSION.SDK_INT>=26)ctx.startForegroundService(i); else ctx.startService(i); p.resolve(true);}catch(Exception e){p.reject("START",e);}}
  @ReactMethod public void stop(Promise p){try{Intent i=new Intent(ctx,RadioEncoderService.class);i.setAction("STOP");ctx.startService(i);p.resolve(true);}catch(Exception e){p.reject("STOP",e);}}
  @ReactMethod public void setMicEnabled(boolean on, Promise p){try{RadioEncoderService.setMic(on);p.resolve(true);}catch(Exception e){p.reject("MIC",e);}}
  @ReactMethod public void queueAudio(String uri,String name,Promise p){try{RadioEncoderService.queue(uri,name);p.resolve(true);}catch(Exception e){p.reject("QUEUE",e);}}
  @ReactMethod public void pickAudio(Promise p){Activity a=getCurrentActivity(); if(a==null){p.reject("ACTIVITY","Sem atividade");return;} pickerPromise=p; Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("audio/*");i.addCategory(Intent.CATEGORY_OPENABLE);a.startActivityForResult(i,PICK);}
  @Override public void onActivityResult(Activity a,int req,int res,@Nullable Intent data){if(req!=PICK||pickerPromise==null)return;Promise p=pickerPromise;pickerPromise=null;if(res!=Activity.RESULT_OK||data==null||data.getData()==null){p.reject("CANCEL","Seleção cancelada");return;}Uri u=data.getData();String n=u.toString();try(Cursor c=ctx.getContentResolver().query(u,null,null,null,null)){if(c!=null&&c.moveToFirst()){int ix=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(ix>=0)n=c.getString(ix);}}p.resolve(new WritableNativeMap(){{putString("uri",u.toString());putString("name",n);}});}
  @Override public void onNewIntent(Intent i){}
  static void emit(String status,boolean connected,String track){if(ctx!=null){WritableMap m=new WritableNativeMap();m.putString("status",status);m.putBoolean("connected",connected);if(track!=null)m.putString("track",track);ctx.getJSModule(com.facebook.react.modules.core.DeviceEventManagerModule.RCTDeviceEventEmitter.class).emit("RadioEncoderStatus",m);}}
}
