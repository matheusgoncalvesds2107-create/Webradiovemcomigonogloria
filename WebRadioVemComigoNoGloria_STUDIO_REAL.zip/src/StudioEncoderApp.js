import React, {useEffect, useState} from 'react';
import {View, Text, StyleSheet, TouchableOpacity, ScrollView, TextInput, PermissionsAndroid, Platform, Alert, DeviceEventEmitter} from 'react-native';
import {NativeModules} from 'react-native';
const {RadioEncoder} = NativeModules;

export default function StudioEncoderApp(){
  const [isBroadcasting,setIsBroadcasting]=useState(false);
  const [micActive,setMicActive]=useState(false);
  const [host,setHost]=useState('sapircast.caster.fm');
  const [port,setPort]=useState('19513');
  const [user,setUser]=useState('source');
  const [mount,setMount]=useState('/QKnuH');
  const [password,setPassword]=useState('');
  const [status,setStatus]=useState('DESCONECTADO');
  const [track,setTrack]=useState('Nenhuma música selecionada');

  useEffect(()=>{ const sub=DeviceEventEmitter.addListener('RadioEncoderStatus', e=>{setStatus(e.status||''); if(e.connected!==undefined)setIsBroadcasting(!!e.connected); if(e.track)setTrack(e.track);}); return ()=>sub.remove(); },[]);

  async function permissions(){
    if(Platform.OS!=='android') return true;
    const p=[PermissionsAndroid.PERMISSIONS.RECORD_AUDIO];
    if(Platform.Version>=33) p.push(PermissionsAndroid.PERMISSIONS.READ_MEDIA_AUDIO); else p.push(PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE);
    const r=await PermissionsAndroid.requestMultiple(p); return Object.values(r).every(x=>x===PermissionsAndroid.RESULTS.GRANTED);
  }
  async function start(){
    if(!password){Alert.alert('Senha do Icecast','Digite a senha da fonte no aparelho. Ela não fica no código.');return;}
    if(!(await permissions())){Alert.alert('Permissões','Autorize o microfone e o acesso aos áudios.');return;}
    try{await RadioEncoder.start({host,port:parseInt(port,10),username:user,mountpoint:mount,password,bitrate:128,sampleRate:44100});}catch(e){Alert.alert('Não foi possível iniciar',String(e?.message||e));}
  }
  async function stop(){try{await RadioEncoder.stop();}catch(e){} setMicActive(false);}
  async function mic(){try{await RadioEncoder.setMicEnabled(!micActive);setMicActive(!micActive);}catch(e){Alert.alert('Microfone',String(e?.message||e));}}
  async function chooseAudio(){try{const r=await RadioEncoder.pickAudio();if(r?.uri){setTrack(r.name||r.uri);await RadioEncoder.queueAudio(r.uri,r.name||'Áudio');}}catch(e){Alert.alert('Áudio',String(e?.message||e));}}
  async function jingle(){try{const r=await RadioEncoder.pickAudio();if(r?.uri){await RadioEncoder.queueAudio(r.uri,r.name||'Vinheta');}}catch(e){}}

  return <View style={styles.container}>
    <View style={styles.header}><Text style={styles.title}>WEB RÁDIO</Text><Text style={styles.subTitle}>Vem Comigo no Glória</Text><Text style={styles.panelBadge}>PAINEL DE CONTROLE / ESTÚDIO</Text></View>
    <ScrollView style={styles.body}>
      <View style={styles.card}><Text style={styles.cardTitle}>TRANSMISSÃO AO VIVO (MEDIACAST ENCODER)</Text><Text style={styles.infoText}>Servidor: {host}:{port}</Text><Text style={styles.infoText}>Mountpoint: {mount} | Qualidade: 128 kbps MP3</Text><Text style={[styles.infoText,status==='CONECTADO'?styles.ok:styles.warn]}>Status: {status}</Text>
        <TextInput style={styles.input} placeholder="Senha Icecast" placeholderTextColor="#6880a0" value={password} onChangeText={setPassword} secureTextEntry/>
        <TouchableOpacity style={[styles.btnBroadcast,isBroadcasting?styles.btnRed:styles.btnGreen]} onPress={isBroadcasting?stop:start}><Text style={styles.btnText}>{isBroadcasting?'🔴 PARAR TRANSMISSÃO':'🟢 INICIAR TRANSMISSÃO AO VIVO'}</Text></TouchableOpacity>
      </View>
      <View style={styles.card}><Text style={styles.cardTitle}>LOCUÇÃO / MICROFONE</Text><TouchableOpacity disabled={!isBroadcasting} style={[styles.btnMic,micActive?styles.btnMicOn:styles.btnMicOff,{opacity:isBroadcasting?1:.45}]} onPress={mic}><Text style={styles.btnText}>{micActive?'🎙️ MICROFONE ABERTO (NO AR)':'🎙️ LIGAR MICROFONE DO CELULAR'}</Text></TouchableOpacity></View>
      <View style={styles.card}><Text style={styles.cardTitle}>CARTUCHEIRA DE VINHETAS E CHAMADAS</Text><View style={styles.row}>{['Vinheta 01','Vinheta 02','Chamada Glória'].map(x=><TouchableOpacity key={x} style={styles.btnJingle} onPress={jingle}><Text style={styles.jingleText}>{x}</Text></TouchableOpacity>)}</View></View>
      <View style={styles.card}><Text style={styles.cardTitle}>PLAYLIST DO CELULAR</Text><Text style={styles.infoText}>▶ Tocando: {track}</Text><TouchableOpacity style={styles.selectBtn} onPress={chooseAudio}><Text style={styles.btnText}>🎵 ESCOLHER ÁUDIO DO CELULAR</Text></TouchableOpacity><Text style={styles.infoText}>A seleção entra no mesmo fluxo MP3 da transmissão.</Text></View>
      <View style={styles.card}><Text style={styles.cardTitle}>HORA CERTA</Text><Text style={styles.infoText}>Disparo automático no início de cada hora; o áudio é inserido no fluxo quando configurado no projeto.</Text></View>
    </ScrollView>
  </View>
}
const styles=StyleSheet.create({container:{flex:1,backgroundColor:'#020612',padding:12},header:{paddingVertical:16,alignItems:'center',borderBottomWidth:1,borderColor:'#00e5ff'},title:{color:'#00e5ff',fontSize:22,fontWeight:'bold'},subTitle:{color:'#fff',fontSize:14,fontWeight:'600'},panelBadge:{color:'#ffcc00',fontSize:10,fontWeight:'bold',marginTop:4,letterSpacing:1},body:{flex:1,marginTop:10},card:{backgroundColor:'#0a1526',padding:14,borderRadius:8,marginBottom:12,borderWidth:1,borderColor:'#132845'},cardTitle:{color:'#00e5ff',fontSize:12,fontWeight:'bold',marginBottom:8},infoText:{color:'#88a0c0',fontSize:11,marginBottom:5},ok:{color:'#00e676'},warn:{color:'#ffcc00'},input:{backgroundColor:'#07101e',color:'#fff',borderWidth:1,borderColor:'#24466d',borderRadius:7,paddingHorizontal:10,paddingVertical:9,marginTop:8},btnBroadcast:{padding:14,borderRadius:8,alignItems:'center',marginTop:10},btnGreen:{backgroundColor:'#00c853'},btnRed:{backgroundColor:'#ff1744'},btnMic:{padding:12,borderRadius:8,alignItems:'center'},btnMicOn:{backgroundColor:'#ff9100'},btnMicOff:{backgroundColor:'#2979ff'},btnText:{color:'#fff',fontWeight:'bold',fontSize:12},row:{flexDirection:'row',gap:8,marginTop:6},btnJingle:{flex:1,backgroundColor:'#1e3a66',padding:10,borderRadius:6,alignItems:'center'},jingleText:{color:'#fff',fontSize:10,fontWeight:'bold'},selectBtn:{backgroundColor:'#1e3a66',padding:12,borderRadius:7,alignItems:'center',marginVertical:8}}
);
