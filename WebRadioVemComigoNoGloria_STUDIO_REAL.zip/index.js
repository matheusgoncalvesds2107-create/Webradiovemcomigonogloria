import {AppRegistry} from 'react-native';
import StudioEncoderApp from './src/StudioEncoderApp';
import {name as appName} from './app.json';
AppRegistry.registerComponent(appName, () => StudioEncoderApp);
