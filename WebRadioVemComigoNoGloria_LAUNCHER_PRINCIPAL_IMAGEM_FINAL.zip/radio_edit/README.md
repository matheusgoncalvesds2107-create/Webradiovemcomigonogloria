# Web Rádio Vem Comigo no Glória — Launcher Principal Final

Versão 2.6 com a nova arte aprovada como launcher/tela de abertura principal.

- Launcher principal com a nova imagem
- MediaCast / Sinal Principal na arte
- Sem “Tocando Agora” na arte principal
- Programação e Áudio disponíveis dentro do aplicativo
- 13 programas com horários das artes
- Pasta `app/src/main/assets/pregacoes/` para adicionar novas pregações MP3
- Workflow: `GERAR APK NOVO - LAUNCHER PRINCIPAL FINAL`
