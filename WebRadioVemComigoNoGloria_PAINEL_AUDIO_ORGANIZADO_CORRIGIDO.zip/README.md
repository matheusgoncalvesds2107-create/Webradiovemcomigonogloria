# Web Rádio Vem Comigo no Glória 

Versão 2.0 do aplicativo da Web Rádio Vem Comigo no Glória.

Inclui:
- Interface própria inspirada no modelo aprovado.
- Rádio ao vivo pelo site oficial da rádio.
- Relógio/Hora Certa em tempo real.
- Chamada de Hora Certa automática no início de cada hora.
- Tocando Agora / área de música.
- Painel de Louvores/Músicas para cadastrar título, cantor e programa no aparelho.
- Palavra do Dia com versículos.
- Programação da rádio.
- Botão Ao Vivo e aviso sobre configuração do MediaCast.
- WhatsApp e compartilhamento.
- Indicador No Ar / conexão.

Identificação Android:
- Nome: Web Rádio Vem Comigo no Glória 
- Application ID: com.vemcomigo.radio.v2
- Versão: 2.0

A transmissão da rádio continua usando o endereço público:
https://webradiovemcomigonogloria.ismyradio.com/
