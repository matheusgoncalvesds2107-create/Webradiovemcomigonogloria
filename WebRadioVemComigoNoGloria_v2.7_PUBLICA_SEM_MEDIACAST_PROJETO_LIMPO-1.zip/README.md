# Web Rádio Vem Comigo no Glória — v2.7 Pública

Versão pública otimizada para aparelhos Android mais modestos, usando o Samsung A13 como referência.

## Esta versão NÃO contém MediaCast integrado
- MediaCast não é carregado nem disponibilizado no aplicativo público.
- Removido o bloco "TOCANDO AGORA".
- Removida a seção/lista dos 13 programas da tela principal.
- Mantido o visual principal otimizado.
- Mantidos rádio ao vivo, painel de áudios, vinhetas, chamadas, pregações e hora certa.

## Gerar APK pelo GitHub Actions
O workflow está em:
`.github/workflows/GERAR_APK_V27_PUBLICA_SEM_MEDIACAST.yml`

Depois de colocar o conteúdo deste ZIP na raiz de um repositório GitHub:
1. Abra **Actions**.
2. Selecione **Gerar APK v2.7 - PUBLICA SEM MEDIA CAST**.
3. Clique em **Run workflow**.
4. Baixe o artefato `WebRadio-v2.7-PUBLICA-SEM-MEDIA-CAST`.
